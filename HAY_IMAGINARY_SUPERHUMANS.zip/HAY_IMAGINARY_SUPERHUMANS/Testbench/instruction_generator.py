print("Enter your Assembly Code:")
instructions = input()
instruction = instructions.split()
hexcode = []
for i in range(len(instruction)):
    if (instruction[i] == 'ADD'):
        hexcode.append('0000' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'SUB'):
        hexcode.append('0010' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'MUL'):
        hexcode.append('0011' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'ADI'):
        hexcode.append('0001' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3])
    elif (instruction[i] == 'AND'):
        hexcode.append('0100' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'ORA'):
        hexcode.append('0101' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'IMP'):
        hexcode.append('0110' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3] + '000')
    elif (instruction[i] == 'LHI'):
        hexcode.append('1000' + instruction[i + 1] + '0' + instruction[i + 2])
    elif (instruction[i] == 'LLI'):
        hexcode.append('1001' + instruction[i + 1] + '0' + instruction[i + 2])
    elif (instruction[i] == 'LW'):
        hexcode.append('1010' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3])
    elif (instruction[i] == 'SW'):
        hexcode.append('1011' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3])
    elif (instruction[i] == 'BEQ'):
        hexcode.append('1100' + instruction[i + 1] + instruction[i + 2] + instruction[i + 3])
    elif (instruction[i] == 'JAL'):
        hexcode.append('1101' + instruction[i + 1] + instruction[i + 2])
    elif (instruction[i] == 'JLR'):
        hexcode.append('1111' + instruction[i + 1] + instruction[i + 2] + '000000')

def convert_to_eight_chars(strings):
    result = []
    for s in strings:
        first_eight_chars = s[:8]
        last_eight_chars = s[8:]
        result.append(first_eight_chars)
        result.append(last_eight_chars)
    return result

reshaped_hexcode = convert_to_eight_chars(hexcode)

inst_set = open(r"rom_init.txt", "w")

for k in range(len(reshaped_hexcode)):
    inst_set.write(str(reshaped_hexcode[k]) + '\n')

for j in range(512 - len(reshaped_hexcode)):
    if j != (511 - len(reshaped_hexcode)):
        inst_set.write(str("11111111") + '\n')
    else:
        inst_set.write(str("11111111"))
